// Adds the camera permission to the Android manifest (needed for the Scan tab). Safe to run more than once.
const fs=require('fs'),path=require('path');
const p=path.join(process.env.CAPACITOR_ROOT_DIR||process.cwd(),'android','app','src','main','AndroidManifest.xml');
if(fs.existsSync(p)){let x=fs.readFileSync(p,'utf8');
if(!x.includes('android.permission.CAMERA')){x=x.replace('<application','<uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application');fs.writeFileSync(p,x);console.log('Camera permission added')}}

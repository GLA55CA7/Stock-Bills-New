const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..'),out=path.join(root,'www','lib');
fs.mkdirSync(out,{recursive:true});
const pick=(dir,names)=>names.map(n=>path.join(root,'node_modules',dir,n)).find(p=>fs.existsSync(p));
const jobs=[['qrcode-generator',['qrcode.js','dist/qrcode.js','js/qrcode.js'],'qrcode.js'],['jspdf',['dist/jspdf.umd.min.js'],'jspdf.umd.min.js']];
for(const [dir,names,to] of jobs){const from=pick(dir,names);if(!from){console.error('Missing '+dir+' - run "npm install" first');process.exit(1)}
fs.copyFileSync(from,path.join(out,to));console.log('copied',to)}

# Stock and Bills - Android app (Capacitor)

Offline inventory and billing app. Bills are A4 and can be shared as PDF, image, or both. Data is stored on the phone only.

## Option A - GitHub builds the APK for you (no Android Studio)
1. Create a free account at github.com, then a new repository (private is fine).
2. On a computer, unzip this folder and upload everything inside it: Add file > Upload files, drag the contents in (include the hidden `.github` folder).
   If `.github` will not upload: Add file > Create new file, name it `.github/workflows/build-apk.yml` and paste in the contents of that file from this folder.
3. Open the Actions tab > "Build APK" > Run workflow (it also starts by itself after an upload). Wait about 5-10 minutes for the green tick.
4. Open the finished run > Artifacts > `stock-bills-apk`. Download and unzip it to get `app-debug.apk`.
5. Copy the APK to your phone, tap it, and allow "Install unknown apps" when asked.

## Option B - Android Studio on a PC
1. Install Node.js 20+ (LTS) and Android Studio. In Android Studio set Settings > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK = 17.
2. In this folder run:
   npm install
   npm run prep
   npx cap add android
   npx cap sync android
   npx cap open android
3. Wait for the Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). Click "locate" to find `app-debug.apk`.

`npm run prep` copies the QR and PDF libraries from node_modules into `www/lib`, so the finished app works offline.

## Changing things
- App name or id: edit `capacitor.config.json` before `npx cap add android`.
- App code: `www/index.html`. After editing run `npm run sync` and rebuild (Option B), or re-upload the file (Option A).
- Try it in a computer browser first: `npm install`, `npm run prep`, `npx serve www`. Sharing falls back to the browser share/download there.

## Using it
- Open any bill: Share PDF, Share image, or Share PDF + image opens the phone share sheet (Gmail, WhatsApp, Drive, ...).
- Printing: share the PDF to your printer app, or save it to Drive/Files and print from there (Android WebView cannot print directly).
- Settings > Export backup regularly and keep the file somewhere safe. Import backup restores it.

## Notes
- Pinned to Capacitor 6 (needs JDK 17). A debug APK is fine for your own phone. The Play Store needs a signed release build and a newer Capacitor.

## Version 1.1 additions
- Stock limits (cannot bill more than in stock), low-stock alerts, shelf and bin per item, many more units.
- Paid/unpaid tracking. "Mark as paid" (or "Already paid in cash") hides the payment QR; you can also turn the payment QR off or on for any bill, one at a time or in bulk (History > Select bills).
- Void bill (restocks items), search, CSV export.
- Scan tab: reads the Bill QR with the camera (or from a photo/image) and checks it against your records.

## Camera permission
The Scan tab needs the camera permission. `scripts/patch-android.js` adds it to the Android manifest automatically (Capacitor runs it after `cap sync`; the workflow also runs it explicitly). If the live camera says it is not available, use "Take a photo or pick an image" on the same screen.

## Updating an existing GitHub repo
Upload the new `stock-bills-app.zip` with the same file name (Add file > Upload files, commit), then run the workflow again.
